package com.example.baeguard.data.model

/*
Classe de modelagem Ambiente
 */
data class Ambiente(
    var id: String = "",
    var nome: String = ""
)
