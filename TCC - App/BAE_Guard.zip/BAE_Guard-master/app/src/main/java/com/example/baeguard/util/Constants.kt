package com.example.baeguard.util

object FirestoreTables{

    val DISPOSITIVO = "Dispositivo"
    val AMBIENTE = "Ambiente"
    val HISTORICO = "Historico"
    val USUARIO = "Usuario"

}